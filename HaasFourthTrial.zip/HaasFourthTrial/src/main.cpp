/*
  Rui Santos
  Complete project details at Complete project details at https://RandomNerdTutorials.com/esp8266-nodemcu-http-get-post-arduino/

  Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files.
  The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
  
  Code compatible with ESP8266 Boards Version 3.0.0 or above 
  (see in Tools > Boards > Boards Manager > ESP8266)
*/

#include <ESP8266WiFi.h>
#include <ESP8266HTTPClient.h>
#include <WiFiClient.h>
#include "ArduinoJson.h"

const char* ssid = "Classic Media";
const char* password = "uvos5775";

//Your Domain name with URL path or IP address with path
String serverName = "http://172.20.10.3/MyProject/php/phpForEsp8266/getApplianceState.php";

// the following variables are unsigned longs because the time, measured in
// milliseconds, will quickly become a bigger number than can be stored in an int.
unsigned long lastTime = 0;
// Timer set to 10 minutes (600000)
//unsigned long timerDelay = 600000;
// Set timer to 5 seconds (5000)
unsigned long timerDelay = 5000;
void changeState(JsonArray &root);

void setup() {
  Serial.begin(115200); 
  int pins[] = {2, 4, 5, 12, 13, 14, 15, 16};
  
  int i;
  for (i = 0; i < 8; i++) {
    pinMode(pins[i], OUTPUT);
    digitalWrite(pins[i], LOW);
  }

  WiFi.begin(ssid, password);
  Serial.println("Connecting");
  while(WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("");
  Serial.print("Connected to WiFi network with IP Address: ");
  Serial.println(WiFi.localIP());
 
  Serial.println("Timer set to 5 seconds (timerDelay variable), it will take 5 seconds before publishing the first reading.");
}

void loop() {
  // Send an HTTP POST request depending on timerDelay
  if ((millis() - lastTime) > timerDelay) {
    //Check WiFi connection status
    if(WiFi.status()== WL_CONNECTED){
      WiFiClient client;
      HTTPClient http;

      String serverPath = serverName + "?temperature=24.37";
      
      // Your Domain name with URL path or IP address with path
      http.begin(client, serverPath.c_str());
      
      // Send HTTP GET request
      int httpResponseCode = http.GET();
      
      if (httpResponseCode>0) {
        Serial.print("HTTP Response code: ");
        Serial.println(httpResponseCode);
        String payload = http.getString();
        Serial.println(payload);

         const size_t bufferSize = JSON_ARRAY_SIZE(1024) + 20;
          DynamicJsonBuffer jsonBuffer(bufferSize);
          JsonArray &root = jsonBuffer.parseArray(payload);
          changeState(root);
        
      }
      else {
        Serial.print("Error code: ");
        Serial.println(httpResponseCode);
      }
      // Free resources
      http.end();
    }
    else {
      Serial.println("WiFi Disconnected");
    }
    lastTime = millis();
  }
}

void changeState(JsonArray &root) {
  int i, j, pins[16], state[16], sync[16];
    const char *val;
    int rows = root[0][2];

    for (i = 0; i < rows; i++)
    {
        for (j = 0; j < 9; j++)
        {
            if (j == 0)
            {
                val = root[i][j];
                pins[i] = atoi(val);
            }
            else if (j == 1)
            {
                val = root[i][j];
                state[i] = atoi(val);
            }
            else if (j == 3)
            {
                val = root[i][j];
                //char a[] = val;
                //startingTime[i] = val;
            }
            else if (j == 4)
            {
                val = root[i][j];
            }
            else if (j == 7)
            {
                val = root[i][j];
                sync[i] = atoi(val);
            }
        }
    }

    //Turn_Off_ON
    //lighting for loop
    for (int i = 0; i <= rows - 1; i++)
    {
        //light up
        if (state[i] == 1)
        {
            Serial.println("ON");
            digitalWrite(pins[i], HIGH);
        }
        else
        {
            Serial.println("OFF");
            digitalWrite(pins[i], LOW);
        }
    }
    // NL();

    for (i = 0; i < rows; i++)
    {
        if (sync[i] == 1)
        {
            Serial.print("pin ");
            Serial.print(pins[i]);
            Serial.println(" Synced");
            // scheduledAppliance(pins[i], state[i]);
        }
        else
        {
            Serial.print("pin ");
            Serial.print(pins[i]);
            Serial.println("  Not Synced");
        }
    }
}
